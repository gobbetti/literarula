package br.com.literalura;

import br.com.literalura.service.BookService;
import br.com.literalura.repository.BookRepository;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookService service = new BookService();
        BookRepository repository = new BookRepository();

        int option;
        do {
            System.out.println("""
                    \n*** LiterAlura ***
                    1 - Buscar livro e salvar
                    2 - Listar livros
                    3 - Listar autores
                    4 - Buscar livros por idioma
                    5 - Sair
                    """);
            option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1 -> service.searchAndSaveBook(scanner);
                case 2 -> repository.listBooks();
                case 3 -> repository.listAuthors();
                case 4 -> repository.listBooksByLanguage(scanner);
                case 5 -> System.out.println("Encerrando...");
                default -> System.out.println("Opção inválida!");
            }
        } while (option != 5);
    }
}
