package br.com.literalura.model;

import java.util.List;

public class Book {
    private String title;
    private List<String> authors;
    private int firstPublishYear;
    private String language;

    public Book(String title, List<String> authors, int firstPublishYear, String language) {
        this.title = title;
        this.authors = authors;
        this.firstPublishYear = firstPublishYear;
        this.language = language;
    }

    public String getTitle() {
        return title;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public int getFirstPublishYear() {
        return firstPublishYear;
    }

    public String getLanguage() {
        return language;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + ''' +
                ", authors=" + authors +
                ", firstPublishYear=" + firstPublishYear +
                ", language='" + language + ''' +
                '}';
    }
}
